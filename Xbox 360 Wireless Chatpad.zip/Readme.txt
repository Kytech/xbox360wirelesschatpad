Installing the LibUSB Driver

Plug-In and Install the Native Drivers for your XBOX 360 Wireless Receiver.
Download LibUSB here. (v1.2.6)
Extract the Archive to a Directory.
Execute the following: Directory/bin/Architecture/install-filter-win.exe
Select "Install a Device Filter".
Select the item with Description "Xbox 360 Wireless Receiver for Windows".
Select "Install" then after the confirmation box select Cancel.
Execute the following path: Directory/bin/inf-wizard.exe
Select "Next".
Select the item with Description "Xbox 360 Wireless Receiver for Windows".
Select "Next" then save the new .inf somewhere.
Select "Install Now" to install the driver.
Select OK at the confirmation, the LibUSB driver should now be installed.



Installing the vJoy Driver

Download vJoy here. (v2.0.2)
Install with at least the vJoy Configuration Application.
Run "Configure vJoy" from the newly created Start Menu folder.
Match the following selection then hit OK:
Basic Axes Selected: X, Y, Z, R/Rz/Rudder
Additional Axes Selected: Rx, Ry
POV Hat Switch: Continuous
POVs: 1
Number of Buttons: 11
The Configuration utility will disappear, the vJoy Driver should now be installed.



Running the Xbox 360 Wireless Chatpad Application

Download the latest version of the application.
Extract all of the files in the archive to a single directory.
Execute "Xbox 360 Wireless Chatpad.exe"
Follow in instruction in the application to connect your controller.




THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.